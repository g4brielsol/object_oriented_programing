package cliente_gui;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static cliente_gui.Cliente_GUI.msg_in;
import static cliente_gui.Cliente_GUI.input_stream;
import static cliente_gui.Cliente_GUI.text_area;
import static cliente_gui.Cliente_GUI.posicao_cursor;
import static cliente_gui.Cliente_GUI.janela_fechada;
import static cliente_gui.Cliente_GUI.qtd_pessoas;

/**
 *
 * @author gabriel
 */
public class ReceiveData extends Thread{
  
    @Override
    public void run() {

        while(janela_fechada == 1)
        {
                try {
                    // le a quantidade de pessoas alterando o texto
                    msg_in = input_stream.readUTF();
                    // coloca essa quantidade no JTextField
                    qtd_pessoas.setText(msg_in);
                    // le a mensagem dos outros clientes
                    msg_in = input_stream.readUTF();
                } catch (IOException ex) {
                    Logger.getLogger(ReceiveData.class.getName()).log(Level.SEVERE, null, ex);
                }
                // coloca a mensagem lida no JTextArea
                text_area.setText(msg_in);
                try{
                // coloca a posicao do cursor que foi pega pelo usuario teclando na classe Trabalho_final()
                text_area.setCaretPosition(posicao_cursor);
                }
                catch(Exception e)
                {
                    // caso as alteracoes tenham sido muito bruscas, coloca o
                    // cursor na posicao inicial para nao dar erro
                    text_area.setCaretPosition(0);
                }
        }
    }
    
}