package cliente_gui;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.awt.event.KeyListener;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.undo.UndoManager;


/** Classe que contem tanto a interface grafica quanto a parte do cliente,
* para ser feita a comunicacao com o server */
public class Cliente_GUI extends javax.swing.JFrame implements KeyListener{

    /** Cria objeto da classe Clipboard para transferir dados de copiar e colar */
    protected Clipboard clipboard = getToolkit().getSystemClipboard();  
    /** Cria objeto da classe UndoManager para fazer os Undos e os Redos */
    protected static UndoManager fazer_refazer = new UndoManager();
    /** Nome do arquivo a ser salvo */
    protected static String nome_arquivo;
    /** Variaveis para a comunicacao com o servidor */
    protected static String msg_in, msg_out;
    /** Variaveis para indicar a posicao do cursor na tela
     * e para indicar se a janela foi fechada*/
    protected static int posicao_cursor, janela_fechada = 1;
    /** interface grafica que o cliente vai usar */
    protected static Cliente_GUI interface_grafica;
    /** socket para a comunicacao com o servidor */
    protected static Socket socket;
    /** comunicacao de entrada com o servidor */   
    protected static DataInputStream input_stream;
    /** comunicacao de saida com o servidor */
    protected static DataOutputStream output_stream;
    /** classe que lida com as entradas do servidor */
    protected static ReceiveData receiver = new ReceiveData();
    /** classe para escolher o arquivo .txt a ser editado  */
    protected static JFileChooser escolher = new JFileChooser();
    /** variavel para representar o caminho do diretorio do arquivo .txt */
    protected static java.io.File arquivo;
    /** variavel para guardar o nome do arquivo .txt aberto */
    protected static String id_arquivo;
    /** variavel para checar se o nome do arquivo foi enviado ao servidor */
    protected static int enviar_id_arquivo = 1;
    /** classe para ler o arquivo .txt */
    protected static StringBuilder ler_arquivo = new StringBuilder();
    
    /** Iniciacao dos componentes da classe Trabalho_final ()
     * @throws java.awt.AWTException */
    public Cliente_GUI() throws AWTException {
        initComponents();
    }
    // codigo gerado pelo NetBeans ao criar um JFrame
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() throws AWTException {

        qtd_pessoas = new javax.swing.JTextField();
        qtd_pessoas.setEditable(false);
        qtd_pessoas.setBounds(0, 0, 120, 2);
        painel = new javax.swing.JPanel();
        refazer = new javax.swing.JButton();
        desfazer = new javax.swing.JButton();
        recortar = new javax.swing.JButton();
        colar = new javax.swing.JButton();
        copiar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane(qtd_pessoas);
        text_area = new javax.swing.JTextArea();
        salvar = new javax.swing.JButton();
        try {   
            socket = new Socket("127.0.0.1", 2000);
            output_stream = new DataOutputStream(socket.getOutputStream()); 
            input_stream = new DataInputStream(socket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        refazer.setText("Refazer");
        refazer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    refazerActionPerformed(evt);
                } catch (IOException ex) {
                    Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        desfazer.setText("Desfazer");
        desfazer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                
                try {
                    desfazerActionPerformed(evt);
                } catch (IOException ex) {
                    Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        recortar.setText("Recortar");
        recortar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    recortarActionPerformed(evt);
                } catch (IOException ex) {
                    Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        colar.setText("Colar");
        colar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    colarActionPerformed(evt);
                } catch (IOException ex) {
                    Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        copiar.setText("Copiar");
        copiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copiarActionPerformed(evt);
            }
        });

        text_area.setColumns(20);
        text_area.setRows(5);
        jScrollPane1.setViewportView(text_area);

        salvar.setText("Salvar");
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelLayout = new javax.swing.GroupLayout(painel);
        painel.setLayout(painelLayout);
        painelLayout.setHorizontalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 745, Short.MAX_VALUE)
                    .addGroup(painelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(copiar, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(colar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(recortar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(desfazer, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(refazer, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(salvar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(qtd_pessoas, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        painelLayout.setVerticalGroup(
            painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(desfazer)
                    .addComponent(refazer)
                    .addComponent(recortar)
                    .addComponent(colar)
                    .addComponent(copiar)
                    .addComponent(salvar)
                    .addComponent(qtd_pessoas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(painel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // funcao do botao Undo
    private void desfazerActionPerformed(java.awt.event.ActionEvent evt) throws IOException {//GEN-FIRST:event_desfazerActionPerformed
        //se for possivel executar o Desfazer
        if(fazer_refazer.canUndo())
        {
            // executa o Desfazer 4 vezes
            for(int counter = 0; counter < 4; counter++)
            {
                fazer_refazer.undo();
            }          
            while(interface_grafica.text_area.getText().length() == 0)
            {
                fazer_refazer.undo();
            }
            desfazer_refazer_comunicacao();
        }
    }//GEN-LAST:event_desfazerActionPerformed
    // funcao do botao Redo
    private void refazerActionPerformed(java.awt.event.ActionEvent evt) throws IOException {//GEN-FIRST:event_refazerActionPerformed
        // se for possivel executar o "Refazer"
        if(fazer_refazer.canRedo())
        { 
            // executa o Refazer 4 vezes
            for(int counter = 0; counter < 4; counter++)
            {
                fazer_refazer.redo();
            }
            while(interface_grafica.text_area.getText().length() == 0)
            {
                fazer_refazer.redo();
            }
            desfazer_refazer_comunicacao();
        }
    }//GEN-LAST:event_refazerActionPerformed

    private void recortarActionPerformed(java.awt.event.ActionEvent evt) throws IOException {//GEN-FIRST:event_recortarActionPerformed
        // pega o texto selecionado na caixa de texto escrita pelo usuario
        String string_recortada = text_area.getSelectedText();
        // cria um objeto com a capacidade de transferir a string recortada
        StringSelection string_selecionada = new StringSelection(string_recortada);
        // coloca a string_selecionada no objeto transferível
        clipboard.setContents(string_selecionada, string_selecionada);
        // substitui o texto selecionado por vazio ("")
        text_area.replaceRange("", text_area.getSelectionStart(), text_area.getSelectionEnd());
        desfazer_refazer_comunicacao();
    }//GEN-LAST:event_recortarActionPerformed

    private void colarActionPerformed(java.awt.event.ActionEvent evt) throws IOException {//GEN-FIRST:event_colarActionPerformed
        try
        {
            // retorna um objeto transferível representando o conteudo atual do clipboard
            Transferable texto_copiado = clipboard.getContents(Cliente_GUI.this);
            // transforma o objeto transferido em string
            String texto_para_colar = (String) texto_copiado.getTransferData(DataFlavor.stringFlavor);
            // substitui o texto nas áreas de início e fim especificadas pela string texto_para_colar
            text_area.replaceRange(texto_para_colar, 
                                   text_area.getSelectionStart(),
                                   text_area.getSelectionEnd());
        }
        catch(Exception e)
        {
            System.out.println("Erro");   
        }
        desfazer_refazer_comunicacao();
            
    }//GEN-LAST:event_colarActionPerformed

    private void copiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copiarActionPerformed
        // retorna o texto selecionado
        String string_copiada = text_area.getSelectedText();
        // cria um string capaz de ser transferida
        StringSelection string_selecionada = new StringSelection(string_copiada);
        // coloca a string_selecionada no conteudo atual do clipboard, que pode ser transferido
        clipboard.setContents(string_selecionada, string_selecionada);
    }//GEN-LAST:event_copiarActionPerformed

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        // cria um janela com a especificacao de salvar
        FileDialog janela_de_salvar = new FileDialog(Cliente_GUI.this, "Salvar arquivo ", FileDialog.SAVE);
        janela_de_salvar.setVisible(true);
        
        // se o arquivo nao for nulo, coloca o titulo na variavel nome_arquivo
        if(janela_de_salvar.getFile() != null)
        {
            // pega o nome do arquivo
            nome_arquivo =  janela_de_salvar.getFile();
            // coloca o nome_arquivo no frame
            setTitle("Docs " + nome_arquivo);
        }
        try
        {
            // instancia o objeto que salva arquivos
            FileWriter salvar_arquivo = new FileWriter(nome_arquivo);
            // pega o texto escrito na area de texto do programa e salva
            salvar_arquivo.write(text_area.getText()) ;
            // colocar o titulo do arquivo
            setTitle("Docs " + nome_arquivo);
            salvar_arquivo.close();
        }
        catch (Exception e)
        {
            
        }
    }//GEN-LAST:event_salvarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {

        // Implementado pelo proprio NetBeans ao criar o JFrame
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable()
        {        
            public void run() 
            {               
                try {
                    interface_grafica = new Cliente_GUI();
                } catch (AWTException ex) {
                    Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
 
                // pega o tamanho da tela do monitor do usuario
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                interface_grafica.setBounds(0, 0, 850, 500);
                // faz a janela do docs ser inicializada no centro da tela do usuario
                interface_grafica.setLocation(dim.width/2-interface_grafica.getSize().width/2, dim.height/2-interface_grafica.getSize().height/2);
                // coloca o nome na janela
                interface_grafica.setVisible(true);
                // faz a janela poder ter varios tamanhos
                interface_grafica.setResizable(true);
                // interface nao fazer scroll lateral
                interface_grafica.text_area.setLineWrap(true);
                // undo e redo sem limites de arquivos salvos
                interface_grafica.fazer_refazer.setLimit(-1);
                //escolher arquivo
                if(escolher.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
                {
                    arquivo = escolher.getSelectedFile();
                    id_arquivo = arquivo.getName();
                    try {
                        Scanner input = new Scanner(arquivo);
                        // ler texto do arquivo
                        while(input.hasNext())
                        {
                            ler_arquivo.append(input.nextLine());
                            ler_arquivo.append("\n");
                        }
                        // coloca o texto do arquivo na text_area do JFrame
                        text_area.setText(ler_arquivo.toString());
                        // coloca o nome do arquivo na janela
                        interface_grafica.setTitle("Docs - Arquivo: " + id_arquivo);
                        input.close();
                        // manda o nome do arquivo para o servidor
                        if(enviar_id_arquivo == 1)
                        {
                            try {
                                output_stream.writeUTF(id_arquivo);
                                msg_out = text_area.getText();
                                output_stream.writeUTF(msg_out);
                            } catch (IOException ex) {
                                Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            enviar_id_arquivo = 0;
                        }
                        

                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                // caso o usuario aperte em cancelar ao abrir um arquivo texto, ele salva um novo
                else
                {
                    interface_grafica.salvar.doClick();
                    // manda o nome do arquivo para o servidor
                    if(enviar_id_arquivo == 1)
                    {
                        try {
                            output_stream.writeUTF(nome_arquivo);
                            msg_out = text_area.getText();
                            output_stream.writeUTF(msg_out);
                        } catch (IOException ex) {
                            Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        enviar_id_arquivo = 0;
                    }
                }
                // listener para qualquer modificacao no texto
                interface_grafica.text_area.getDocument().addUndoableEditListener 
                (new UndoableEditListener()
                   {
                        // verificar as mudancas do arquivo
                        public void undoableEditHappened(UndoableEditEvent e)
                        {
                                Cliente_GUI.fazer_refazer.addEdit(e.getEdit());                                
                        }

                   }                      
                );
                // vai para a funcao de listener do teclado
                text_area.addKeyListener(interface_grafica);
                // inicia o loop que checa as mensagens vindas do servidor
                receiver.start();
                // listener para o fechamento da janela do cliente
                interface_grafica.addWindowListener(new java.awt.event.WindowAdapter()
                {
                    @Override
                    public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                        // se fechar a janela, fechar as conexoes e interromper a thread
                        janela_fechada = 0;
                        receiver.interrupt();
                        try {
                            socket.close();
                            input_stream.close();
                            output_stream.close();
                        } catch (IOException ex) {
                            Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                );        
            }     
        });
        
    }
  
    // Implementado pelo proprio NetBeans ao criar o JFrame
    // Variables declaration - do not modify//GEN-BEGIN:variables
    /** Campo de texto para informar a quantidade de
     * pessoas que editam o mesmo arquivo */
    public static javax.swing.JTextField qtd_pessoas;
    /** Botao para colar o que esta copiado na area de transferencia */
    private javax.swing.JButton colar;
    /** Botao para copiar o que foi selecionado */
    private javax.swing.JButton copiar;
    /** Botao para desfazer alteracoes */
    protected javax.swing.JButton desfazer;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel painel;
    private javax.swing.JButton recortar;
    private javax.swing.JButton refazer;
    private javax.swing.JButton salvar;
    /** Area de texto para os usuarios escreverem seus documentos */
    public static javax.swing.JTextArea text_area;
    // End of variables declaration//GEN-END:variables

    @Override
    public void keyTyped(KeyEvent e) {
        //do nothing
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // do nothing
    }

    @Override
    public void keyReleased(KeyEvent e) {
        try
        {
            // pega a posicao do cursor
            posicao_cursor = text_area.getCaretPosition();
            // pega o texto do box do JFrame
            msg_out = text_area.getText();
            // envia a mensagem para o servidor
            output_stream.writeUTF(msg_out);
            // seta o cursor na posicao anterior
            text_area.setCaretPosition(posicao_cursor);
            //output_stream.flush();
            } catch (IOException ex) {
            Logger.getLogger(Cliente_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }

    private void desfazer_refazer_comunicacao() throws IOException {
            // pega a posicao do cursor
            posicao_cursor = text_area.getCaretPosition();
            // pega o texto do box do JFrame
            msg_out = text_area.getText();
            // envia a mensagem para o servidor
            output_stream.writeUTF(msg_out);
            // seta o cursor na posicao anterior
            text_area.setCaretPosition(posicao_cursor);
          
    }

}
