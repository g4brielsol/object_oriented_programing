package servidor;

/**
 *
 * @author gabriel
 */
/** Classe para administrar a porta de conexao com os clientes e rodar o server */
public class Servidor {   
    /** Define a porta de conexao e roda a thread do serv*/
    public static void main(String[] args) 
    { 
        int port = 2000;
        Server server = new Server(port);
        // colecao de clientes em lista
        server.start();
    }

}
