package servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gabriel
 */
public class Server extends Thread{
    
    private int port;
    /** Server que armazena os sockets de comunicacao */
    protected ServerSocket server;
    /** Lista de clientes conectados ao server */
    protected ArrayList<ServerThread> lista_clientes = new ArrayList<>();
    /** cliente conectado ao server que vai ser adicionado a lista de clientes*/
    protected ServerThread cliente;
    
    /** Recebe a porta de comunicacao com o server para os clientes poderem 
     * mandar mensagens
     * @param porta */
    public Server(int porta)
    {
        this.port = porta;
    }
    /** Retorna a lista de clientes conectados ao server
     * @return  */
    public List<ServerThread> get_lista_clientes()
    {
        return(lista_clientes);  
    }
    
    @Override
    public void run()
    {
        try
        {
            server = new ServerSocket(port);
            // reusar porta 2000 ao rodar o servidor novamente
            server.setReuseAddress(true);
            while(true)
            {
                try{
                    Socket connection = server.accept();
                    System.out.println("Conectou");
                    cliente = new ServerThread(this, connection);
                    lista_clientes.add(cliente);
                    cliente.start();         
                }
                catch(Exception e)
                {

                }               
            }
        }
        // fecha as conexoes
        catch(IOException e)
        {
                if (server != null && !server.isClosed()) {
                try
                {
                    server.close();
                    lista_clientes.remove(cliente);
                } 
                catch (IOException ex)
                {
                    ex.printStackTrace(System.err);
                }
            }          
            e.printStackTrace();
        }
    }
}
