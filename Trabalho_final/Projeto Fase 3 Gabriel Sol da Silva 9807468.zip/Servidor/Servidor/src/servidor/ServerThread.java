/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author gabriel
 */
public class ServerThread extends Thread {
    /** Variavel para administrar a conexao swcada cliente com o server */
    protected Socket server_socket;
    /** Variavel para administrar o server, que aceita as conexoes e administra a 
     * lista de clientes */
    protected Server server;
    /** Nome de cada arquivo .txt de cada cliente*/
    protected String nome;
    /** comunicacao de saida com o cliente */
    private DataOutputStream output_stream;
    /** comunicacao de entrada com o cliente */
    private DataInputStream input_stream;
    /** atualizacao e a variavel de msgs a serem enviadas aos cliente
     * qtd_pessoas e a quantidade de pessoas que editam o mesmo arquivo*/
    protected static String atualizacao, qtd_pessoas;
    /** variavel para checar quais clientes devem receber as alteracoes em seus
     devidos arquivos .txt */
    protected static String name;
    /** variavel usada para receber o nome do arquivo .txt*/
    protected int receber_id_arquivo = 1;
    /** variavel para contar quantas pessoas editam o mesmo arquivo */
    protected static int contador_de_pessoas;
    /** Construtor da classe, recebe o server e os sockets de conexao
     * com cada cliente, alem de criar as entradas e saidas de comunicacao
     * @param server
     * @param server_socket
     * @throws java.io.IOException */
    public ServerThread(Server server, Socket server_socket) throws IOException
    { 
        this.server = server;
        this.server_socket = server_socket;
        this.output_stream = new DataOutputStream(server_socket.getOutputStream());
        this.input_stream = new DataInputStream(server_socket.getInputStream());       
    }
   
    @Override
    public void run()
    {
        while(true)
        {
            try {
                lidar_cliente();
            } catch (IOException | InterruptedException ex) {
                Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
                break;
            }
        }
    }
    /** Funcao para receber o nome dos arquivos .txt, contar quantas pessoas
     * editam o mesmo arquivo, enviar as alteracoes de cada arquivo para os
     * clientes certos e por fim salva o arquivo .txt localmente
     * @throws java.io.IOException
     * @throws java.lang.InterruptedException */
    protected void lidar_cliente() throws IOException, InterruptedException
    {
        try
        {
            // identifica de qual arquivo esta vindo a alteracao no texto para fazer as futuras
            // alteracoes em cada arquivo proprio
            atualizacao = input_stream.readUTF();
            if(receber_id_arquivo == 1)
            {
                this.nome = atualizacao;
            }

        }
        catch(IOException e)
        {
            input_stream.close();
        }
        name = this.nome;
        contador_de_pessoas = 0;
        // se ja recebeu o nome, agora passa as mensagens para cada cliente
        if(receber_id_arquivo == 0)
        {
            // conta quantas pessoas estao editando o arquivo
            List<ServerThread> clientes_lista = server.get_lista_clientes();
            for(ServerThread cliente : clientes_lista)
            {
                //conta a quantidade de usuarios editando o mesmo arquivo
                if (cliente.nome.equals(name) == true)
                {
                    contador_de_pessoas += 1;
                }
            }
            for(ServerThread cliente : clientes_lista)
            {
                System.out.println(cliente.nome);
                // os usuarios que editam o mesmo arquivo vao receber as modificacoes devidas
                if (cliente.nome.equals(name) == true)
                {
                    cliente.send(atualizacao, cliente.nome);
                    
                }
            }       
        }
        // apos receber o nome do arquivo, muda a variavel para passar as mensagens
        receber_id_arquivo = 0;
                
    }
    
    private void send(String atualizacao, String cliente_nome) throws IOException
    {
        // quantas pessoas editam o mesmo arquivo
        qtd_pessoas = "Pessoas:" + String.valueOf(contador_de_pessoas);
        output_stream.writeUTF(qtd_pessoas);
        // envia a mensagem
        output_stream.writeUTF(atualizacao);
        FileWriter salvar_arquivo = new FileWriter(cliente_nome);
        // salva o texto escrito no programa
        salvar_arquivo.write(atualizacao) ;
        salvar_arquivo.close();
    } 

}
