Foi levado em conta que cada pessoa poderia pegar somente uma midia emprestado da biblioteca.

As datas de emprestimo, de devolucao e a data atual para a devolucao sao pedidas para o usuario 
digitar somente para efeitos de teste do programa, para verificar se os atrasos de mais de 7 dias
estao sendo computados de maneira correta ou nao. Em um programa finalizado, essas datas seriam 
coletadas direto do sistema para nao haver problemas de falsificacao, mas para efeitos de correcao
do trabalho, seria demorado para o professor ou o monitor corrigir. 

O arquivo Aula_pratica_1.java contem o programa em si, os arquivos Aluno.java e Midia.java 
contem as classes Aluno e Midia respectivamente que sao importados pelo arquivo Aula_pratica_1.java
utilizar durante o funcionamento do programa.
