O programa principal, que contem o main(), e o arquivo Aula_pratica_2.java

O programa primeiramente pergunta se o usuario deseja escolher entre a lista encadeada ou a lista sequencial. (o usuario deve digitar 0 ou 1)

Depois o programa pergunta ao usuario se ele deseja inserir usuarios, remover algum usuario, imprimir a lista ou prosseguir com o programa. (o usuario deve digitar 0, 1, 2, ou 3)

Se o usuario escolher digitar os usuarios, ele deve informar quantos nomes serao digitados, entre 1 e 20, se ele quiser digitar mais de 20 nomes, deve digitar os 20 primeiros, depois escolher digitar mais 20 nomes e assim por diante.

Se o usuario escolher remover um usuario, e so digitar o nome dele que o programa o removera da lista.

Se o usuario escolher imprimir a lista, o programa ira printar os nomes dos usuarios.

Se o usuario escolher continuar com o programa, ele ira para o proximo passo 
                        |||
                        vvv

A seguir o programa pergunta se o usuario deseja começar o programa do zero (voltar a pergunta da lista encadeada ou sequencial) ou se o usuario deseja terminar o programa. (o usuario deve digitar 0 ou 1)